#ifndef COMMON_INIT_H
#define COMMON_INIT_H

void init_git(const char **argv);

#endif /* COMMON_INIT_H */
