#ifndef DIAGNOSE_H
#define DIAGNOSE_H

#include "strbuf.h"

struct option;
struct repository;

enum diagnose_mode {
	DIAGNOSE_NONE,
	DIAGNOSE_STATS,
	DIAGNOSE_ALL
};

int option_parse_diagnose(const struct option *opt, const char *arg, int unset);

int create_diagnostics_archive(struct repository *r,
			       struct strbuf *zip_path,
			       enum diagnose_mode mode);

#endif /* DIAGNOSE_H */
